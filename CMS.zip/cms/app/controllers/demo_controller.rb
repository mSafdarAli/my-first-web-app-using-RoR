class DemoController < ApplicationController
	layout 'application'
  def index
  end
end
